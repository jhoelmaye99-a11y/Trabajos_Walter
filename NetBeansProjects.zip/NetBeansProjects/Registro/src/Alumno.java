/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jhoel
 */
public class Alumno {
    String Nombre;
    String Carrera;
    String Semestre;
    int Grupo;
    double Promedio;
    
    public Alumno(){
        
    }
    
    public Alumno(String Nombre, String Carrera, String Semestre, int Grupo, double Promedio) {
        this.Nombre = Nombre;
        this.Carrera = Carrera;
        this.Semestre = Semestre;
        this.Grupo = Grupo;
        this.Promedio = Promedio;
    }
    
    
    public String getNombre (){
        return Nombre;
    }
    public void setNombre (String Nombre){
        this.Nombre = Nombre;
    }
    
        public String getCarrera (){
        return Carrera;
    }
    public void setCarrera (String Carrera){
        this.Carrera = Carrera;
    }
    public String getSemestre (){
        return Semestre;
    }
    public void setSemestre (String Semestre){
        this.Semestre = Semestre;
    }
    public int getGrupo (){
        return Grupo;
    }
    public void setGrupo (int Grupo){
        this.Grupo = Grupo;
    }
    public double getPromedio (){
        return Promedio;
    }
    public void setPromedio (double Promedio){
        this.Promedio = Promedio;
    }
    
    
    
    
}


