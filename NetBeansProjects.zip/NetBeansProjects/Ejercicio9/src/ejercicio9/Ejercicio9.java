/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio9;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.print("Ingresa un año: ");
        int anio = scanner.nextInt();


        if (anio % 4 == 0) {
            if (anio % 100 == 0) {
                if (anio % 400 == 0) {
                    System.out.println("El año " + anio + " ES bisiesto.");
                } else {
                    System.out.println("El año " + anio + " NO es bisiesto (es divisible por 100 pero no por 400).");
                }
            } else {
                System.out.println("El año " + anio + " ES bisiesto.");
            }
        } else {
            System.out.println("El año " + anio + " NO es bisiesto (no es divisible por 4).");
        }
    }
    
}
