/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cafetera1;

/**
 *
 * @author jhoel
 */
public class Principal {
    
    
    public static void main(String[] args) {
        Cafetera miCafetera = new Cafetera ("oster", "negro");
        
        miCafetera.prepararCafe();
    }
}
