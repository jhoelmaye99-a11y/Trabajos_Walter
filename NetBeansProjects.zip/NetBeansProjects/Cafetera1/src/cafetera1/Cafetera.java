/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cafetera1;

/**
 *
 * @author jhoel
 */
public class Cafetera {
    
    String marca ;
    String color ;
    
    public Cafetera (String marca, String color){
        this.marca = marca;
        this.color = color;

    }
    public void prepararCafe(){
        
        System.out.println("1. Calentando agua a 90ª");
        System.out.println("2. Filtrando el agua a traves del cafe molido ");
        System.out.println("3. Tu cafe esta listo");
    
    }
}
