/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        String clavecorrecta = "jhoel1910"; 
        
        
        System.out.print("Ingresa tu contraseña: ");
        String claveingresada = scanner.nextLine();
        
        
        if (claveingresada.equals(clavecorrecta)) {
            System.out.println("Bienvenido Acceso permitido.");
            
        } else {
            System.out.println("Contraseña incorrecta Acceso denegado.");
        }
    }
    
}
