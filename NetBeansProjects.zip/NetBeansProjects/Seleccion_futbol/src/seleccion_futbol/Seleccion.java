/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seleccion_futbol;

/**
 *
 * @author jhoel
 */
public class Seleccion {
    
    protected int id;
    protected String Nombre;
    protected String Apellidos;
    protected int Edad;
    
    public Seleccion(){
    
    }

    public Seleccion(int id, String Nombre, String Apellidos, int Edad) {
        this.id = id;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Edad = Edad;
    }
    
    public int getid(){
        return id;       
    }   
    public void setid(){
        this.id = id;
    }
    
    public int getEdad(){
        return Edad;
    }
    public void setEdad(){
        this.Edad = Edad;
    }
    
    public String getNombre(){
        return Nombre;
    }
    public void setNombre(){
        this.Nombre = Nombre;
    }
    
    public String getApellidos(){
        return Apellidos;
    }
    public void setApellidos(){
        this.Apellidos = Apellidos;
    }
    
    public void concentrarse(){
        System.out.println("concentrarse");
    }
    public void viajar (){
        System.out.println("Viajar");
    }
    
    
}



