/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seleccion_futbol;

/**
 *
 * @author jhoel
 */
public class Masajista extends Seleccion{
    
    private String Titulacion;
    private int añosExperiencia;
    
    
    public Masajista(){
        super();
    }

    public Masajista(String Titulacion, int aniosExperiencia, int id, String Nombre, String Apellidos, int Edad) {
        super(id, Nombre, Apellidos, Edad);
        this.Titulacion = Titulacion;
        this.añosExperiencia = aniosExperiencia;
    }
    
    public int getañosExperiencia(){
        return añosExperiencia;
    }
    public void setañosExperiencia(){
        this.añosExperiencia = añosExperiencia;
    }
    
    public void darMasaje(){
        System.out.println("Dar Masaje ");
    }
    
    
    
    
}
