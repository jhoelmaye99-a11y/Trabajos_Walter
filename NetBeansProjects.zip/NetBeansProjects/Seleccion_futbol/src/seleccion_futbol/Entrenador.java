/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seleccion_futbol;

/**
 *
 * @author jhoel
 */
public class Entrenador extends Seleccion{
    
    String idFederacion;
    
    public Entrenador(){
    
    super();
      
    }

    public Entrenador(String idFederacion, int id, String Nombre, String Apellidos, int Edad) {
        super(id, Nombre, Apellidos, Edad);
        this.idFederacion = idFederacion;
    }
     
    public String getidFederacion(){
        return idFederacion;
    }
    public void setidFederacion(){
        this.idFederacion = idFederacion;
    }
    
    public void dirigirPartido(){
        System.out.println("Dirigir Partido ");
    }
    public void dirigirEntreno(){
        System.out.println("Dirigir Entreno ");
    }
    
    
    
}
