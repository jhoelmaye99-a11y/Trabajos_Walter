/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seleccion_futbol;

/**
 *
 * @author jhoel
 */
public class Futbolista extends Seleccion {
    
    int dorsal;
    String demarcacion;
    
    public Futbolista(){
        
        super ();
    }

    public Futbolista(int dorsal, String demarcacion, int id, String Nombre, String Apellidos, int Edad) {
        super(id, Nombre, Apellidos, Edad);
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }
    
    public int getdorsal(){
        return dorsal;
    }
    public void setdorsal(){
        this.dorsal = dorsal;
    }
    
    public String getdemarcacion(){
        return demarcacion;
    }
    public void setdemarcacion(){
        this.demarcacion = demarcacion;
    }
    
    public void entrenar(){
        System.out.println("Entrenar ");
    }
    public void jugar_partido(){
        System.out.println("Jugar Partido ");
    }
    
    @Override
    public void viajar(){
        System.out.println("El Futbolista Viaja");
    }
    public void concentrarse(){
        System.out.println("El Futbolista se Concentra");
    }      
    
    
}





