/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jhoel
 */
public class Empleados {
    String Nombre;
    String Area;
    String Cargo;
    String FechaI;
    double Salario;
    int Documento;
    
    public Empleados(){
        
    }

    public Empleados(String Nombre, String Area, String Cargo, String FechaI, double Salario, int Documento) {
        this.Nombre = Nombre;
        this.Area = Area;
        this.Cargo = Cargo;
        this.FechaI = FechaI;
        this.Salario = Salario;
        this.Documento = Documento;
    }
    
    public String getNombre (){
        return Nombre;
    }
    public void setNombre (String Nombre){
        this.Nombre = Nombre;
    }
    
    public String getArea (){
        return Area;
    }
    public void setArea (String Area){
        this.Area = Area;
    }
    
    public String getCargo (){
        return Cargo;
    }
    public void setCargo (String Cargo){
        this.Cargo = Cargo;
    }
    
    public String getFechaI (){
        return FechaI;
    }
    public void setFechaI (String FechaI){
        this.FechaI = FechaI;
    }
    
    public double getSalario (){
        return Salario;
    }
    public void setSalario (double Salario){
        this.Salario = Salario;
    }
    
    public int getDocumento (){
        return Documento;
    }
    public void setDocumento (int Documento){
        this.Documento = Documento;
    }
}
