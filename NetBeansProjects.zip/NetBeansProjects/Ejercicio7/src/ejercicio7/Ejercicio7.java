/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingresa el nombre de un mes: ");
        String mes = entrada.nextLine();

        switch (mes) {
            case "diciembre":
            case "enero":
            case "febrero":
                System.out.println("Estación: Invierno");
                break;

            case "marzo":
            case "abril":
            case "mayo":
                System.out.println("Estación: Primavera");
                break;

            case "junio":
            case "julio":
            case "agosto":
                System.out.println("Estación: Verano");
                break;

            case "septiembre":
            case "octubre":
            case "noviembre":
                System.out.println("Estación: Otoño");
                break;

            default:
                System.out.println("Mes no válido. Asegúrate de escribir bien el nombre del mes.");
                break;
        }
      
    }
    
}
