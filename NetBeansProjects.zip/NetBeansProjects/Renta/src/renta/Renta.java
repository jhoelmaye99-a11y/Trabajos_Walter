/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package renta;


import java.util.Scanner;
public class Renta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner (System.in);
        
        String Tamaño = "";
        int meses = 0;
        int precio = 0;
        
        System.out.println("De que tamaño desea su Apartamento, Grande, Mediano, Pequeño. ");
        Tamaño = entrada.next(). toLowerCase();
        
        System.out.println("Para cuantos meses lo desea: ");
        meses = entrada.nextInt();
        
        switch (Tamaño) {
            case "grande":
                precio = 2000000;
                break;
                
            case "mediano":
                precio = 1000000;
                break;
                
            case "pequeño":
                precio = 500000;
                break;
                
            default:
                throw new AssertionError();
        }
      
        Apartamento A = new Apartamento (precio, meses);
        
        switch (Tamaño) {
            case "grande":
                System.out.println("El costo total del tiempo de su renta seria de: $ " +  A.CalcularCosto());
                break;
                
            case "mediano":
                System.out.println("El costo total del tiempo de su renta seria de: $ " +  A.CalcularCosto());
                break;
                
            case "pequeño":
                System.out.println("El costo total del tiempo de su renta seria de: $ " +  A.CalcularCosto());
                break;
                
            default:
                throw new AssertionError();
        }
        
    }
    
}
