/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package renta;


public class Apartamento {
    
    
    
    int meses, precio;
    

    public Apartamento(int precio, int meses) {
        this.precio = precio;
        this.meses = meses;
    }
    
    
    public int CalcularCosto (){
        return precio * meses;
    }
    
    
    
}
