/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numero1 = 0, numero2 = 0, operacion = 0, resultado = 0;
        
        System.out.println("Elija la operacion a realizar segun estos valores Suma(1) Resta(2) Multiplicacion(3) Division(4)");
        operacion = entrada.nextInt();
        
        System.out.println("Ingresa el primer numero: ");
        numero1 = entrada.nextInt();
        
        System.out.println("Ingresa el segundo numero: ");
        numero2 = entrada.nextInt();
        
        switch (operacion) {
            case 1: resultado = numero1 + numero2;
                System.out.println("El resultado de la suma es: " + resultado);
                break;
                
            case 2: resultado = numero1 - numero2;
                System.out.println("El resultado de la resta es: " + resultado);
                break;
                
            case 3: resultado = numero1 * numero2;
                System.out.println("El resultado de la multiplicacion es: " + resultado);
                break;
                
            case 4: resultado = numero1 / numero2;
                System.out.println("El resultado de la division es: " + resultado);
                break;
                
            default: System.out.println("Eror la operacion no existe");
                break;
        }
        
    }
    
}
