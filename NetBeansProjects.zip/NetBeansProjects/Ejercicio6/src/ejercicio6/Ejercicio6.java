/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numero = 0;
        
        System.out.println("Ingrese el numero del dia: ");
        numero = entrada.nextInt();
        
        switch (numero) {
            
            case 1: System.out.println("Estamos en Lunes");
                break;
            
            case 2: System.out.println("Estamos en el Martes");
                break;
            
            case 3: System.out.println("Estamos en el Miercoles");
                break;
            
            case 4: System.out.println("Estamos en el Jueves");
                break;
                
            case 5: System.out.println("Estamos en el viernes");
                break;
                
            case 6: System.out.println("Estamos en el Sabado");
                break;
                
            case 7: System.err.println("Estamos en el Jueves");
            
            default:System.out.println("Error el dia no existe");
                break;
        }    
                
    }
    
}
