/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("--- SISTEMA DE ESTACIONAMIENTO ---");
        System.out.println("1. Moto");
        System.out.println("2. Carro");
        System.out.println("3. Autobús");
        System.out.print("Selecciona el tipo de vehículo (1-3): ");
        int tipoVehiculo = scanner.nextInt();


        System.out.print("Ingresa el número de horas estacionado: ");
        int horas = scanner.nextInt();

        double tarifaHora = 0;
        boolean opcionValida = true;

 
        switch (tipoVehiculo) {
            case 1:
                tarifaHora = 2000;
                break;
            case 2:
                tarifaHora = 4000;
                break;
            case 3:
                tarifaHora = 8000;
                break;
            default:
                System.out.println("Opción de vehículo no válida.");
                opcionValida = false;
                break;
        }


        if (opcionValida) {
            double totalSinDescuento = tarifaHora * horas;
            double totalPagar;

            if (horas > 8) {

                double descuento = totalSinDescuento * 0.20;
                totalPagar = totalSinDescuento - descuento;
                System.out.println("\n-> Se aplicó un 20% de descuento por permanencia mayor a 8 horas.");
            } else {
                totalPagar = totalSinDescuento;
            }


            System.out.println("\n--- RESUMEN DE COBRO ---");
            System.out.println("Horas estacionado: " + horas);
            System.out.println("Tarifa por hora: $" + tarifaHora);
            System.out.println("Total a pagar: $" + totalPagar);
        }
    }
    
}
