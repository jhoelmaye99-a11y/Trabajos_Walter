/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package producto1;

/**
 *
 * @author jhoel
 */
public class Principal {

    
    public static void main(String[] args) {
        Producto Salchipapa = new Producto ("001", "salchipapa", 25000);
        Producto Hamburguesa = new Producto ("002", "Hamburguesa", 12000);
        
        System.out.println("== PRODUCTO 1 ==");
        
        Salchipapa.mostrarInformacion();
        
        System.out.println("Precio con descuento: " + Salchipapa.calcular());
        
        System.out.println("");
        
        System.out.println("== PRODUCTO 2 ==");
                
        Hamburguesa.mostrarInformacion();
        
        System.out.println("Precio con descuento: " + Hamburguesa.calcular());
        
        
    }
    
}
