/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hotel;

import java.util.Scanner;
public class Habitacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner hn = new Scanner (System.in);
        String habitacion = "";
        int noches = 0;
        double precio = 0;
        
        System.out.println("Que tipo habitacion desea: Sencilla, Doble, Suite. ");
        habitacion = hn.next().toLowerCase();
        
        System.out.println("Cuantas noches se hospedara: ");
        noches = hn.nextInt();
        
        switch (habitacion) {
            case "sencilla":
                precio = 50.000;
                break;
            
            case "doble":
                precio = 80.000;
                break;
                
            case "suite":    
                precio = 120.000;
                break;
                
            default:
                throw new AssertionError();
        }
        
        /*Objeto */
        
        Noches h = new Noches (habitacion, noches, precio);
        
        switch (habitacion) {
            case "sencilla":
                System.out.println("El costo total de su estadia en la Habitacion Sencilla es de: $" + h.calcularSencilla());
                break;
                
            case "doble":
                System.out.println("El costo total de su estadia en la Habitacion Doble es de: $" + h.calcularDoble());
                break;
                
            case "suite":
                System.out.println("El costo total de su estadia en la Suite es de: $" + h.calcularSuite());
                break;
            default:
                throw new AssertionError();
        }
        
        
            
 
    }
    
}
