/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel;

import java.util.Scanner;
public class Noches {
    
    int noches;
    double precio;

    public Noches(String habitacion, int noches, double precio) {
        this.noches = noches;
        this.precio = precio;
    }
    
    public double calcularSencilla (){
        return noches * precio;
    }
    
    public double calcularDoble (){
        return noches * precio;
    }
    
    public double calcularSuite(){
        return noches * precio;
    }
    
}
