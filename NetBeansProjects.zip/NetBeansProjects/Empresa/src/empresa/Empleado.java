/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa;

/**
 *
 * @author jhoel
 */
public class Empleado {
    
    String nombre;
    int cedula, horasTrabajadas;
    double valorHora;

    public Empleado(String nombre, int cedula, int horasTrabajadas, double valorHora) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.horasTrabajadas = horasTrabajadas;        
        this.valorHora = valorHora;
    }
    
    
    public double calcularPago (){
        
        if (horasTrabajadas > 80 ) {
            
            return (valorHora +( valorHora * 0.25)) * horasTrabajadas ;
            
        }
        
        else if (horasTrabajadas <= 80){
            
            return ( horasTrabajadas * valorHora);
        }       
        return 0;
        
    }
    
    public String evaluarJornada (){
        
        if (horasTrabajadas > 80 ){
            
            System.out.println("Jornada con horas extra ");
        }
        else if (horasTrabajadas  <= 80 && horasTrabajadas >= 60 ){
            
            System.out.println("Jornada completa");
        }
        else if (horasTrabajadas < 60 ){
            
            System.out.println("Jornada incompleta");
        }       
        return null ;
        
    }
    
    public void mostrarInformacion (){
        
        System.out.println("Nombre: " + nombre );
        System.out.println("Cedula: " + cedula );
        System.out.println("Horas trabajadas: " + horasTrabajadas );
        System.out.println( "Total del pago: " + calcularPago());
        evaluarJornada();
               
        
    }
    
    
    
}
