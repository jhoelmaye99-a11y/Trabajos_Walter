/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empresa;

import java.util.Scanner;
public class PruebaEmpleado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        
    String nombre = "";
    int cedula = 0, horasTrabajadas = 0;
    double valorHora = 20000, recargo = 0;
    

    
    Empleado A = new Empleado ("Jhoel", 1065202617, 236, valorHora);
    A.mostrarInformacion();


    Empleado B = new Empleado ("Patricia", 49755162, 75, valorHora );
    B.mostrarInformacion();

    
    Empleado C = new Empleado ("Diosemiro", 6696162, 50, valorHora );
    C.mostrarInformacion();    
    
    }
          

}
