/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package promedio;

/**
 *
 * @author jhoel
 */
public class Promedio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int numero1 = 5;
       int numero2 = 20;
       int numero3 = 50;
       int resultado = 0;
       
       resultado = (numero2 + numero1 + numero3);
       
        System.out.println("El resultado de la suma de los 3 numero es " + resultado);
    }
    
}
