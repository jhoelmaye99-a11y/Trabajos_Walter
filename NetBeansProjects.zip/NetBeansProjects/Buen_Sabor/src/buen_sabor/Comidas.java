/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buen_sabor;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class Comidas {
    
    Scanner teclado = new Scanner (System.in);

public double paisa( double total, double descuento, double adicion){
    System.out.println("Desea la adicion ( 1 para si / 2 para no )");
    adicion = teclado.nextInt();
    
    if (adicion == 1 ){
        total = 25000;
        adicion = 25000 * 0.30;
        descuento = total * 0.10;
        total = total + adicion - descuento;
        
        
        System.out.println("Bandeja Paisa");
        System.out.println("Descuento " + descuento);
        System.out.println("Adicion " + adicion);
        System.out.println("Total " + total);
        return total;
    }
    
    else {
        total = 25000;
        descuento = total * 0.10;
        total = total - descuento;
        System.out.println("Bandeja Paisa");
        System.out.println("Descuento " + descuento);        
        System.out.println("Total " + total);
        return total;
    }   
}

public double mondongo(double total, double descuento, double adicion){
    System.out.println("Desea la adicion ( 1 para si / 2 para no )");
    adicion = teclado.nextInt();
    
        if (adicion == 1 ){
        total = 20000;
        adicion = 20000 * 0.20;
        descuento = total * 0.15;
        total = total + adicion - descuento;
        
        
        System.out.println("Mondongo");
        System.out.println("Descuento " + descuento);
        System.out.println("Adicion " + adicion);
        System.out.println("Total " + total);
        return total;
    }
    
    else {
        total = 20000;
        descuento = total * 0.15;
        total = total - descuento;
        System.out.println("Mondongo");
        System.out.println("Descuento " + descuento);
        System.out.println("Total " + total);
        return total;
    }   
}

public double sancocho_de_cerdo( double total, double descuento, double adicion){
    System.out.println("Desea la adicion ( 1 para si / 2 para no )");
    adicion = teclado.nextInt();
    
    if (adicion == 1 ){
        total = 25000;
        adicion = 25000 * 0.20;
        descuento = total * 0.10;
        total = total + adicion - descuento;        
        
        System.out.println("Sancocho de cerdo");
        System.out.println("Descuento " + descuento);
        System.out.println("Adicion " + adicion);
        System.out.println("Total " + total);
        return total;
    }
    
    else {
        total = 25000;
        descuento = total * 0.10;
        total = total - descuento;
        System.out.println("Sancocho de cerdo");
        System.out.println("Descuento " + descuento);
        System.out.println("Total " + total);
        return total;
    }   
}

public double menu_del_dia (double total){
    total = 25000;
    System.out.println("Menu del Dia");
    System.out.println("Total " + total);
    return total;
}
    
    
}
