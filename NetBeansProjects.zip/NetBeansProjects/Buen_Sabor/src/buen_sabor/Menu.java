/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package buen_sabor;
import javax.swing.JOptionPane;
import java.util.Scanner;


public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        String aparecerM;
        int Menu;
        double descuento = 0, adicion = 0, total = 0;
        Comidas op = new Comidas();
        
        System.out.println("Desea el Menu? (Ingrese si o no)");
        aparecerM = teclado.next();
        
        switch (aparecerM){
            case "si": case"SI": case"Si":
            System.out.println("     Menu               Precio            adicion         Descuento");
            System.out.println("");
            System.out.println("1) Bandeja Paisa        25.000      Chicharron/Chorizo       10%");
            System.out.println("2) Mondongo             20.000      Ensalada/Aguacate        15%");
            System.out.println("3) Sancocho de cerdo    25.000      Ensalada/Aguacate        10%");
            System.out.println("4) Menu del dia         25.000             N/A               N/A");
            System.out.println("----------------------------------------------------------------");
            
            
            System.out.println("Que desea ordenar ");
            Menu = teclado.nextInt();
            
            switch (Menu) {
                case 1 -> op.paisa (total, descuento, adicion); 
                
                case 2 -> op.mondongo (total, descuento, adicion);
                
                case 3 -> op.sancocho_de_cerdo (total, descuento, adicion);
                
                case 4 -> op.menu_del_dia (total);
            }
                    

        }
        
    }
    
}
