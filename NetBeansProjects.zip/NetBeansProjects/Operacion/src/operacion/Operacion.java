/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operacion;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Operacion {

    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        String nombre = "";
        int numero1 = 0, numero2 = 0, resultado = 0, operacion = 0;
        
        
        System.out.println("Cual es tu nombre? ");
        nombre = entrada.nextLine();
        
        System.out.println("Elija la operacion a realizar segun estos valores Suma(1) Resta(2) Multiplicacion(3) Division(4)");
        operacion = entrada.nextInt();
        
        System.out.println("Ingresa el primer numero: ");
        numero1 = entrada.nextInt();
        
        System.out.println("Ingresa el segundo numero: ");
        numero2 = entrada.nextInt();
      
        if (operacion == 1){
            resultado = numero1 + numero2;
            System.out.println("Hola " + nombre + " el resultado de su suma es: " + resultado);
        }
        else if (operacion == 2){
            resultado = numero1 - numero2;
            System.out.println("Hola " + nombre + " el resultado de la resta es: " + resultado);
        }
        else if (operacion == 3){
            resultado = numero1 * numero2;
            System.out.println("Hola " + nombre + " el resultado de su multiplicacion es: " + resultado);
        }
        else if (operacion == 4){
            resultado = numero1 / numero2;
            System.out.println("Hola " + nombre + " el resultado de su division es: " + resultado);
        }
        
     
    }
    
}
