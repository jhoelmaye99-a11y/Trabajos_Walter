/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int nota = 0;
        
        System.out.println("Ingrese su Nota: ");
        nota = entrada.nextInt();
        
        if (nota >= 90 && nota <= 100) {
            System.out.println("Excelente");
        } 
        else if (nota >= 70 && nota < 90) {
            System.out.println("Aprobado");
        } 
        else if (nota >= 0 && nota < 70) {
            System.out.println("Reprobado");
        }
        
        
    }
    
}
