/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa_transporte;

import java.util.Scanner;
public class Vehiculo {
    
    Scanner entrada = new Scanner (System.in);
    
    int kilometros;
    int vehiculo;
    double precio;

    public Vehiculo(int kilometros, int vehiculo, double precio) {
        this.kilometros = kilometros;
        this.vehiculo = vehiculo;
        this.precio = precio;
    }
    
    
    

    public double CalculoAutomovil (){
        
        return precio * kilometros;
    }
    
    public double CalculoCamion (){
        
        return precio * kilometros;
    }
    
    public double CalculoBus (){
        
        return precio * kilometros;
    }
    
    
    
}
