/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empresa_transporte;

import java.util.Scanner;

public class Cobro {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        int kilometros = 0, tipoVehiculo = 0;
        double precio = 0;

        System.out.println("Ingrese el tipo de vehiculo: ");
        System.out.println("1) Automovil");
        System.out.println("2) Camion");
        System.out.println("3) Bus");
        tipoVehiculo = entrada.nextInt();

        System.out.println("Ingrese los kilometros del viaje: ");
        kilometros = entrada.nextInt();

        // Definir el precio según el tipo de vehículo
        switch (tipoVehiculo) {
            case 1:
                precio = 1000;
                break;
            case 2:
                precio = 2000;
                break;
            case 3:
                precio = 1500;
                break;
            default:
                System.out.println("Tipo de vehículo no válido.");
                return;
        }

        // Crear objeto de la clase Vehiculo
        Vehiculo v = new Vehiculo(kilometros, tipoVehiculo, precio);

        // Llamar al método correspondiente
        switch (tipoVehiculo) {
            case 1:
                System.out.println("El valor a pagar de su viaje en Automovil es: " + v.CalculoAutomovil());
                break;
            case 2:
                System.out.println("El valor a pagar de su viaje en Camion es: " + v.CalculoCamion());
                break;
            case 3:
                System.out.println("El valor a pagar de su viaje en Bus es: " + v.CalculoBus());
                break;
        }
    }
}

