/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        
        System.out.print("Ingresa el precio total del producto ($): ");
        double precioBase = entrada.nextDouble();

        
        System.out.print("Ingresa tu tipo de membresía (A, B o C): ");
        char membresia = entrada.next().toUpperCase().charAt(0);
        double porcentajeDescuento = 0.0;

     
        switch (membresia) {
            case 'A':
                porcentajeDescuento = 0.20; 
                break;
            case 'B':
                porcentajeDescuento = 0.10; 
                break;
            case 'C':
                porcentajeDescuento = 0.05; 
                break;
            default:
                System.out.println("Membresía no válida. No se aplicará descuento base.");
                break;
        }

        if (precioBase > 100) {
            System.out.println("-> ¡Felicidades! Se añade un 5% de descuento adicional por compras mayores a $100.");
            porcentajeDescuento += 0.05; 
        }

        double montoDescuento = precioBase * porcentajeDescuento;
        double precioFinal = precioBase - montoDescuento;


        System.out.println("\n--- Resumen de Compra ---");
        System.out.println("Precio inicial: $" + precioBase);
        System.out.println("Descuento total aplicado: " + (porcentajeDescuento * 100) + "% ($" + montoDescuento + ")");
        System.out.println("Total a pagar: $" + precioFinal);
    }
    
}
