/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package ejercicio;

/**
 *
 * @author jhoel
 */
import java.util.Scanner;
public class Ejercicio {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int edad = 0;
        
        System.out.println("Ingrese su edad: ");
        edad = entrada.nextInt();
        
        if (edad >= 18){
            System.out.println("Acceso Concedido");
        }
        else if (edad < 18){
            System.out.println("Acceso Denegado");
        
        }
        
    }
}
